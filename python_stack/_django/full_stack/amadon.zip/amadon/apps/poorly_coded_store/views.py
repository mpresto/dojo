from django.shortcuts import render, redirect
from .models import Order, Product


def index(request):
    context = {
        "all_products": Product.objects.all()
    }
    return render(request, "store/index.html", context)


def process_checkout(request):
    # process form data and get price
    quantity_from_form = int(request.POST["quantity"])
    product_id = float(request.POST["product_id"])
    product_price = Product.objects.get(id=product_id).price
    total_charge = quantity_from_form * product_price

    # create new order object from form data, get order_id from sessions
    print("Charging credit card...")
    new_order = Order.objects.create(quantity_ordered=quantity_from_form, total_price=total_charge)
    request.session['new_order_id'] = new_order.id

    return redirect('/confirmation')


def payment_confirmation(request):
    # calculate new totals
    all_orders = Order.objects.all()
    item_count = 0
    total_price = 0
    for order in all_orders:
        item_count += order.quantity_ordered
        total_price += order.total_price

    # pass to template
    context = {
        'new_order': Order.objects.get(id=request.session['new_order_id']),
        'item_count': item_count,
        'total_price': total_price,
    }

    return render(request, "store/checkout.html", context)